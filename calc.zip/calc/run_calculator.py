import sys
from pathlib import Path


def main():
    project_root = Path(__file__).resolve().parent
    calculator_path = project_root / 'calculator.py'
    if not calculator_path.exists():
        raise FileNotFoundError(f'Calculator file not found: {calculator_path}')
    sys.path.insert(0, str(project_root))
    import calculator
    calculator.main()


if __name__ == '__main__':
    main()
