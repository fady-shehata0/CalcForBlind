import unittest

import calculator


class CalculatorTests(unittest.TestCase):
    def test_basic_math(self):
        self.assertAlmostEqual(calculator.evaluate('2+3*4'), 14.0)
        self.assertAlmostEqual(calculator.evaluate('50%'), 0.5)
        self.assertAlmostEqual(calculator.evaluate('2^3'), 8.0)
        self.assertAlmostEqual(calculator.evaluate('sin(30)'), 0.5, places=6)

    def test_errors(self):
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate('2+')
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate('1/(2-2)')
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate('(1+2')


if __name__ == '__main__':
    unittest.main()
